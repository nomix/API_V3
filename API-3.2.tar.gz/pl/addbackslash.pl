#!/usr/bin/perl -w
$string = "";
for ($i=0;$i<@ARGV;$i++) {
 $string .= $ARGV[$i];
 $string .= " ";
}
$string =~ s/([\\\$\#\&\%\;\/\<\>\=\*\+\-\?\^\~\@\{\}\:\.\!\[\]\"\'\|\`\_\ \(\)])/\\$1/g;
$string =~ s/\\\ $//g;
print $string;
