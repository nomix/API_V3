#! perl


############################
# Variables                #
############################


# archive log directory 
$logarchDir   = "/home/was/logrotate/archive" ;

# log file : files list to be rotated 
$listfic   = "/home/was/logrotate/logfiles.txt" ;


# script log file 
$error_log = '/home/was/logrotate/errorScript.log' ;

$hostName ;


############################
# pr_error                 #
############################

%name_of_month   = (
	'1'	=>	'January',
	'2'	=>	'February',
	'3'	=>	'March',
	'4'	=>	'April',
	'5'	=>	'May',
	'6'	=>	'June',
	'7'	=>	'Jully',
	'8'	=>	'August',
	'9'	=>	'September',
	'10'	=>	'October',
	'11'	=>	'November',
	'12'	=>	'December',
);

sub pr_error {
	if (open(ERRORLOG,">>$error_log")) {
		($sec,$min,$hour,$mday,$mon,$year) = localtime(time) ;
		$year += 1900; ++$mon ;
		$month="$name_of_month{$mon}" ;
		print ERRORLOG "$month $mday $hour:$min:$sec $hostName ROTATE ERROR::$_[0]\n" ;
		close (ERRORLOG) ;
	}
	else {
		print "ERROR : it can't open the log file'$error_log'\n" ;
	}
};



############################
# routine principale       #
############################

open(FIC,"<$listfic") || die("can't open datafile: $!");
while (<FIC>) {
	chomp ; s/#.*//; next unless length;
	push @list_op , $_ ;
}


$fileName ;
	
use Sys::Hostname;
$hostName = lc (hostname);

foreach $ligne1 (@list_op) {
	
	($ligne,$app) = split ( / / , $ligne1 );

	my $cmd ;
	my $cmd1 ;
	my $cmd2 ;
        my $logFile = $ligne ;

	if (! -e $logFile) {
		pr_error ("-CRITICAL-,\"Error : directory or files to be rotated don't exist : $logFile\"");
	};

        $logFile = $ligne . ".9" ;

	if ( -e $logFile) {
        	$cmd = "rm -f $logFile " ;
		system $cmd ;
	}


	for ($i=2; $i > 0; $i--) {
		my $oldName ;
		my $newName ;

		$oldName = $ligne . ".$i";
		$newName = $ligne . "." . ($i+1);
		if ( -e $oldName) {
			$cmd = "mv  $oldName $newName ";
			system $cmd;
		}
	}


	$cmd1 = "cp  " . $ligne . " " . $ligne . ".1";
	system $cmd1;
	$cmd2 = "cp  " . $ligne . ".1 " . $ligne . ".copie";
	system $cmd2;
	
        

	# Purge of the file 
	$logFile = $ligne ;
	unless (open(FH, ">$logFile")) {
		pr_error "-CRITICAL-,\"Error : Purge failed '$logFile' ($!)\"";
	}

	close (FH) ;
	
	($sec,$min,$hour,$mday,$mon,$year) = localtime(time) ;
	$year += 1900; ++$mon ;
	$month="$name_of_month{$mon}" ;
	#$zippedName = $logarchDir . "archive/" . $hostName . "_" . $app . "_" . $mday  . "_" . $month . ".gz" ;
	$zippedName = sprintf "%s/%s_%s_%.4D_%.2D_%.2D.gz", $logarchDir, $hostName ,$app ,$year, $mon,$mday;



	$cmd = "gzip -1 -q " . $ligne . ".copie";
	system $cmd;
	$cmd = "mv  " . $ligne . ".copie.gz " . $zippedName ;
	system $cmd;	
	
}


exit 0;
