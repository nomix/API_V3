1.ABOUT
2.THE CONCEPT
3.HOW TO INSTALL
4.HOW TO CONFIGURE
5.HOW TO UPDATE
6.HOW TO UNINSTALL
7.THE UTILISATION GUIDE
8.LIMITATION
9.TODO
10.WHAT'S NEW IN THIS VERSION


1. ABOUT

It's based on the X2P TOOLKIT GPL3. 
see http://www.xpress2people.com/x2ptoolkit


2. THE CONCEPT

The API is a layer between the Korn Shell and the administrative Unix command or differents products as WebSphere, Oracle, etc. It's include a bunch of Korn Shell functions gathered into specifics functionnalities libraries. The goal is to simplify the administration scripts. 


3. HOW TO INSTALL

Pre-requisite

- Korn Shell 

Be insure that it's the first time that you install it. Cause it will waste the current version if it exist and you'll loose all current configuration. See the section 5 to know how to update.

a) Copy the tar file and the installAPI.ksh files into the home of the owner products.
b) Log into the owner products user and execute the installAPI.ksh
   myhost:> sh ./installAPI.ksh
c) The install script will propose you an adapted wastab listing. You can copy and paste it into the API/conf/wastab


4. HOW TO CONFIGURE

I) WebSphere and IHS Components
 a) Configuring the waslib.conf (API/conf/waslib.conf)
   - The waslib.conf is normally, automaticaly configured by the installAPI.ksh.
   - It's the WebSphere common variable used by the API
   - You can verify if the value have been correctly setup.
 b) Configuring the wastab (API/conf/wastab)
   - The wastab file indicate to the differents WebSphere administrative scripts, the WebSphere components to handle or not.
   - You can use the API/bin/genwastab.ksh to generate your wastab automatically.
   or
   - Edit the file manually
   - The stanza of this file : CELL:NODE:object:AUTOMATICSTART[Y/N] 
     CELL indicate the cell of the component
     NODE indicate the node name of the component
     object indicate the object name. 
	For an application server, it's the application server name
	For an nodeagent, it's : nodeagent (no more possiblities)
	For a DMGR(Domain Manager), it's : dmgr (no more possibilities)

* IMPORTANT NOTE : verify if there's no spaces left at the end of the entries strings. If there's some, the entry will not be concidered and excluded. You'll have weards behaviours in you start/stop scripts.

 c) Configuring the conf/ihskdb.conf (used by the checkca.sh script
   - The entry format is : <full path kdb file name> <encrypted password>
     ex.: /opt/WebSphere/IHS/ssl/CCI_IHS_Key.kdb {xor}KzosKw==
   - To encode the password, use the function encodewaspwd
     ex.: encodewaspwd mypassword

5. HOW TO UPDATE

Same things than the brand new install procedure. At the difference, that you'll add the swith -u to the installAPI.ksh.

a) Copy the tar file and the installAPI.ksh files into the home of the owner products.
b) Log into the owner products user and execute the installAPI.ksh
   myhost:> sh ./installAPI.ksh -u
c) You can validate the successfull upgrade by loading the API and run the "hapi" command and verify the version in the header.


6. HOW TO UNINSTALL

All is located under the API directory.

So you can uninstall it by doing a rm -R ./API 


7. UTILISATION GUIDE

There's two ways to use this API. Firt (a), by loading the functions libraries in your Shell or the second (b) by using it in your scripts.

a) Shell 
 - To load the API in your Shell
	1. Go to the API directory. ex.: myhost:> cd ~/API
	2. Load the API with the script la (load all). ex.: myhost:> . ./la
	3. To verify if the API is well loaded, you can call the help API. ex.: myhost:> hapi -v
	   If you get a message with the API version, it's mean that the API is well loaded.
	   If you get this message : "ksh: hapi:  not found" it's mean that something is wrong and the API is still unloaded.

b) Scripts
 - To use it in your scripts, you need to load the appropriates libraries in functions of your needs at the begining of your 
   scripts. It works as an "include" clause in C,C++ or "import" clause in java.
   After that point in your script, you can call the API functions.

	1. First of all, it's required to load the API configuration files. It will load all environment variables that the 
	   API needs. If you don't load it first, the API will not works.
	   ex.: 
		#!/bin/ksh
		# Load the API configuration
		. ~/API/conf/waslib.conf

 	2. Choose the required libraries and load it in your script.
	   ex.:
		#!/bin/ksh
		# Load the API configuration
		. ~/API/conf/waslib.conf
		# Load the API libraries
		. ${STOP}/lib/comlib.fnc
		. ${STOP}/lib/webadmlib-02.fnc

	3. You are now able to use the API function from the loaded libraries.
	   ex.:
		#!/bin/ksh
                # Load the API configuration
                . ~/API/conf/waslib.conf
                # Load the API libraries
                . ${STOP}/lib/comlib.fnc
                . ${STOP}/lib/webadmlib-02.fnc
		# Beging of my hello world!
		ps2 "Hello world!"

c) hapi, the API help
 - If you need to know only one function by heart it's "hapi", the API help. It list all the content of the libraries and give you the functions syntaxes, return code, etc. 
 - To list the available libraries : myhost:> hapi -l
 - To list the available function from a library : myhost:> hapi comlib
 - To list the details on a specific function : myhost:> hapi comlib p2s


.8 LIMITATIONS

- wastab and scripts can only handle locals components.

And too many.. ;o)

.9 TODO

- Rename the delcert function like removecert. To avoid confusion with delcerts that can be understood as show details certificat instead deleting certificat.
- Make the backupconfig.sh errors verbose. Cause when the script return an error, there's difficult to understand why. 

.10 WHAT'S NEW IN THIS VERSION

Version 3.2
 - bin/startwas60.sh
  * bug fixed

Version 3.1r13 (still called 3.1r12 cause they don't like the number 13)(ridiculous!)
 - bin/movehlogs.sh
  * bug fixed
 - bin/checkca.sh
  * add the CTG keyring

Version 3.1r12
 - bin/genwastab.ksh
  * WAS 6.1 compatibility
 - installAPI.ksh
  * change the hard coded API home directory

Version 3.1r11
 - bin/startwas60.sh
  * Bug fixed
   -> -d doesn't works (wrong variable) 
 - bin/probe*
  * Configuration externalisation
   -> now to configure the asprober script (probe-mms.ksh, probe-auth-int.ksh and probe-aut-ext.ksh) you need to do it by the API/conf/asprober.conf
 - bin/checkca.sh
  * Bugs fixed
   -> tee doesn't append in the cacheck.log file.
 - lib/webadmlib-02.fnc
  * new function
   -> genepagentprop : Generate the Introscope EP Agent properties

Version 3.1r10
 - bin/statuswas60.sh
  * Give the status of WAS components, IHS, EPAgent,
 - bin/startwas60.sh
  * -new switch
   -> -h Help : print help
   -> -e EPagent : Do not start EP agent
   -> -d DMGR : Do not start the DMGR
   -> -n Node Agents : Do not start Node Agents
   -> -a Application Servers : Do not start Application Server
 - bin/stopwas60.sh
  * -new switch
 - bin/genwastab.ksh
  * A completly new script. Engine improvement.
 - bin/checkca.ksh
  * Bugs fix
   -> Exclude properties files included in a /temp/ directory
   -> Improve the the equal(=) character handling in a keyring password 

Version 3.1r9
- bin/startwas60.sh
  * SINGLE NODE MODE : a new switch to use on a WAS base install (single node). It will not try to start node agents and dmgr.
  * Do not start IHS mode : a new switch to use when you don't want to start IHS with this script
  * Check the WSWS1037E Error is found in the SystemOut.log. If so, the AS returned code is set to 100 in the ~/API/logs/startwas.log
- lib/webadmlib-02.fnc
  * nodeagentstart : sourcing the profile name variable from the wastab instead to be dynamic. 
  * nodeagentstop : sourcing the profile name variable from the wastab instead to be dynamic.
  * managerstart : sourcing the profile name variable from the wastab instead to be dynamic.
  * managerstop : sourcing the profile name variable from the wastab instead to be dynamic.
  * applicationstart : sourcing the profile name variable from the wastab instead to be dynamic.
  * applicationstop : sourcing the profile name variable from the wastab instead to be dynamic.
  * _wastab : adapted to handle the 2 new columns (profilename and profilepath)
- bin/genwastab.sh
  * including for the node and dmgr, a fifth columns containing the profile name and a sixth for the profile root path
  * including the backup dmgr initialy excluded by previous version
- conf/wastab
  * New format
    -> CELLNAME:NODENAME:COMPONENTNAME:ACTIVED[Y/N]:PROFILENAME:PROFILEPATH
  * New limitation
- bin/stopwas60.sh
  * The scripts have some bugs fixed. Instead to generate dynamically the profile path, the value is sourced statically in the wastab.
   -> Instead to generate dynamically the profile path, the value is sourced statically in the wastab. 
   -> The scripts can only handle locals component.
   -> By default it'll stop IHS in step 6
   -> New option : -i to not stop IHS
   -> Option -s for Single node mode
- bin/checkca.sh
  * Bugs fixed
   -> Missing entries in the output logs
- installAPI.ksh
  * Generate the wastab file each time (upgrade or not)
  * Step the logfile.txt (rotatelog) generation if it's an upgrade
